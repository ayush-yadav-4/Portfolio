// src/components/ThreeDCard.js
import React from 'react';
import { motion } from 'framer-motion';

const ThreeDCard = ({ title, date, description, image }) => {
  return (
    <motion.div
      className="relative bg-white p-6 rounded-xl shadow-lg transition-transform transform hover:scale-105 hover:shadow-2xl"
      whileHover={{ scale: 1.05, rotate: [0, 0, 5, -5, 0], transition: { duration: 0.5 } }}
    >
      <div className="relative z-10">
        <div className="h-32 flex items-center justify-center mb-6 bg-gray-50 rounded-lg">
          <img 
            src={image} 
            alt={title} 
            className="max-h-full max-w-full object-contain p-2"
            onError={(e) => {
              e.target.onerror = null;
              e.target.src = 'https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png';
            }}
          />
        </div>
        <div className="text-2xl font-bold mb-2 text-gray-800">{title}</div>
        <div className="text-sm text-yellow-500 font-semibold mb-4">{date}</div>
        <div className="text-gray-600 text-sm leading-relaxed">{description}</div>
      </div>
    </motion.div>
  );
};


const cards = [
  {
    title: "Chat Application",
    date: "Real-time Messaging",
    description: "A WhatsApp-inspired chat application built with MERN stack and Socket.io. Features include real-time messaging, user authentication, file sharing, and message encryption. Supports both individual and group chats with message status indicators.",
    image: "https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png"
  },
  {
    title: "Tripyee",
    date: "AI Travel Planner",
    description: "A personalized vacation planner using AI to create custom travel itineraries. Built with Next.js and Node.js, it analyzes user preferences to generate tailored travel plans with interactive maps and real-time weather updates.",
    image: "https://raw.githubusercontent.com/github/explore/28b02bbc9ad9f7a503c43775aebeb515dc2da5fc/topics/nextjs/nextjs.png"
  },
  {
    title: "CloudNavigator",
    date: "AWS Automation",
    description: "An AI-powered AWS service deployment tool using Python and React. Features natural language processing for converting requirements into CloudFormation templates, with automated security practices and cost optimization.",
    image: "https://raw.githubusercontent.com/github/explore/fbceb94436312b6dacde68d122a5b9c7d11f9524/topics/aws/aws.png"
  },
  {
    title: "Zoom Clone",
    date: "Video Conferencing",
    description: "A real-time video conferencing application built with WebRTC and Socket.io. Features include video/audio calls, screen sharing, chat functionality, and room creation. Supports multiple participants with low latency communication.",
    image: "https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/typescript/typescript.png"
  },
  {
    title: "Reelify",
    date: "Short-form Content Platform",
    description: "A modern short-form video platform inspired by Instagram Reels. Built with React and Node.js, featuring infinite scroll, user engagement metrics, content creation tools, and AI-powered content recommendations.",
    image: "https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png"
  },
  {
    title: "Coming Soon",
    date: "Next Project",
    description: "Stay tuned for my next exciting project! Always learning and building new things in the world of web development.",
    image: "https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"
  }
];

function Cards() {
  return (
    <div className="flex justify-center items-center bg-gray-100">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-7 m-12 " >
        {cards.map((card, index) => (
          <ThreeDCard
            key={index}
            title={card.title}
            date={card.date}
            description={card.description}
            image={card.image}
          />
        ))}
      </div>
    </div>
  );
}

export default Cards;
