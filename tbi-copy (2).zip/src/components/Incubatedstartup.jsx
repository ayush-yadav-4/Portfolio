import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/effect-coverflow';
import 'swiper/css/pagination';
import { EffectCoverflow, Pagination, EffectCards } from 'swiper/modules';

const projectData = [
  {
    id: 1,
    title: "Chat Application",
    category: "Real-time Communication",
    description: "A feature-rich chat application inspired by WhatsApp, built with the MERN stack. Features include real-time messaging using Socket.io, user authentication, message history, file sharing, and end-to-end message encryption. The app supports both individual and group chats with message status indicators.",
    imageUrl: "https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png",
    skills: ["React.js", "Node.js", "MongoDB", "Socket.io", "Express.js", "JWT", "WebSockets"]
  },
  {
    id: 2,
    title: "Tripyee",
    category: "Travel Planning Platform",
    description: "An intelligent vacation planner that creates personalized travel itineraries. Built with Next.js and Node.js, it uses AI to analyze user preferences, budget, and interests to generate custom travel plans. Features include interactive maps, real-time weather updates, and integration with booking platforms.",
    imageUrl: "https://raw.githubusercontent.com/github/explore/28b02bbc9ad9f7a503c43775aebeb515dc2da5fc/topics/nextjs/nextjs.png",
    skills: ["Next.js", "Node.js", "MongoDB", "TailwindCSS", "REST APIs", "AI Integration", "Maps API"]
  },
  {
    id: 3,
    title: "CloudNavigator",
    category: "AWS Automation Tool",
    description: "An innovative AI-powered tool that simplifies AWS service deployment. Built using Python and React, it features natural language processing to convert user requirements into AWS CloudFormation templates. Includes automated security best practices, cost optimization, and infrastructure monitoring.",
    imageUrl: "https://raw.githubusercontent.com/github/explore/fbceb94436312b6dacde68d122a5b9c7d11f9524/topics/aws/aws.png",
    skills: ["Python", "React.js", "AWS", "NLP", "CloudFormation", "REST APIs", "Security"]
  },
  {
    id: 4,
    title: "Zoom Clone",
    category: "Video Conferencing",
    description: "A real-time video conferencing application built with WebRTC and Socket.io. Features include video/audio calls, screen sharing, chat functionality, and room creation. Supports multiple participants with low latency communication.",
    imageUrl: "https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png",
    skills: ["WebRTC", "Socket.io", "Node.js", "Express.js", "React.js", "Real-time Communication"]
  },
  {
    id: 5,
    title: "Reelify",
    category: "Short-form Content Platform",
    description: "A modern short-form video platform inspired by Instagram Reels. Built with React and Node.js, featuring infinite scroll, user engagement metrics, content creation tools, and AI-powered content recommendations.",
    imageUrl: "https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png",
    skills: ["React.js", "Node.js", "MongoDB", "FFmpeg", "AI Recommendations", "Cloud Storage"]
  }
];

const Incubatedstartup = () => {
  return (
    <div className="flex flex-col lg:flex-row bg-gray-100 py-16">
      <div className="flex-1 flex flex-col justify-center items-center p-8 lg:pr-12">
        <h1 className="text-5xl text-center mb-8 font-bold text-gray-800">Major Projects</h1>
        <p className="text-xl text-gray-600 mb-8 leading-relaxed max-w-2xl text-center lg:text-left">
          As a passionate MERN stack developer, I've built several projects that demonstrate my expertise in full-stack development. 
          Each project showcases different aspects of my technical skills, from real-time communication to AI integration and cloud deployment.
        </p>
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <div className="w-12 h-12 rounded-full bg-yellow-500 flex items-center justify-center">
              <span className="text-white font-bold">5+</span>
            </div>
            <span className="text-lg text-gray-700">Major Projects Completed</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center">
              <span className="text-white font-bold">20+</span>
            </div>
            <span className="text-lg text-gray-700">Technologies Used</span>
          </div>
        </div>
      </div>
      <div className="flex-1 flex justify-center items-center p-8">
        <Swiper
          effect={'cards'}
          grabCursor={true}
          modules={[EffectCards]}
          className="h-[450px] w-[300px] md:h-[550px] md:w-[400px]"
        >
          {projectData.map(project => (
            <SwiperSlide key={project.id} className="bg-white rounded-xl shadow-lg p-6">
              <div className="h-32 mb-6 overflow-hidden rounded-lg bg-gray-50 flex items-center justify-center">
                <img 
                  src={project.imageUrl} 
                  alt={project.title} 
                  className="w-24 h-24 object-contain"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png';
                  }}
                />
              </div>
              <h2 className="text-2xl font-bold text-gray-800 mb-2">{project.title}</h2>
              <div className="text-yellow-500 font-semibold mb-4">{project.category}</div>
              <p className="text-gray-600 text-sm leading-relaxed mb-4">{project.description}</p>
              <div className="border-t pt-4">
                <h3 className="text-sm font-semibold text-gray-700 mb-2">Technologies Used:</h3>
                <div className="flex flex-wrap gap-2">
                  {project.skills.map((skill, index) => (
                    <span 
                      key={index}
                      className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full hover:bg-yellow-100 transition-colors"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default Incubatedstartup;
